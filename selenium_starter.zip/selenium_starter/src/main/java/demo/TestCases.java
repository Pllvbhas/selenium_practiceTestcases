package demo;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//Selenium Imports
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
///


public class TestCases {
    static ChromeDriver driver;
    public TestCases()
    {
        System.out.println("Constructor: TestCases");
        WebDriverManager.chromedriver().timeout(30).setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    }

    public void endTest()
    {
        System.out.println("End Test: TestCases");
        driver.close();
        driver.quit();
    }
//    public static void scrollDownHalfPage(WebDriver driver, String yAxis) {
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("window.scrollBy({ top: " + yAxis + ", behavior: 'smooth' })");
//    }

//    public  void testCase04(){
//        System.out.println("Start Test case: testCase02");
//        //navigate to google homepage  www.google.com
//        driver.get("https://www.google.com");
//        //  find the search box Using Locator "Name" "q"
//        //enter text Pallavi Patil Using Locator "Name" "q"
//        driver.findElement(By.name("q")).sendKeys("Pallavi Patil");
//        // Locate google search button and click on it.
//        driver.findElementByXPath("(//input[@aria-label='Google Search'])[1]").click();
//        // verify the text Pallavi Patil is displayed Using Locator "XPath" //*[contains(text(),'Pallavi Patil')]
//
//        //count the number of hyperlinks Using Locator "Partial Link Text" "Pallavi Patil"
//        List<WebElement> hyperlinks = driver.findElementsByPartialLinkText("Pallavi Patil");
//        int count = hyperlinks.size();
//        System.out.println("Number of hyperlinks are: " + count);
//    }
//    public  void testCase05() throws InterruptedException {
//        System.out.println("Start Test case for Book my show: testCase05");
//        //navigate to google homepage  https://in.bookmyshow.com/explore/home/chennai
//        driver.get("https://in.bookmyshow.com/explore/home/chennai");
//        //Inspect all the  recomanded movie links available on the page  Using Locator "XPath" //div[@class='sc-lnhrs7-2 eQezya']/child::div/a
//        List<WebElement> recommanded_movie_list = driver.findElements(By.xpath("//div[@class='sc-lnhrs7-2 eQezya']/child::div/a/div/div/div/img"));
//        //print urls of all recomanded movies
//        for (WebElement movie: recommanded_movie_list){
//            //movie.getAttribute("src");
//            System.out.println("URL is: " + movie.getAttribute("src"));
//        }
//        // 1100 is pixel value
//        scrollDownHalfPage(driver, "1100");
//        Thread.sleep(60000);
//        //print the name of second item in premier list Using Locator "XPath" //h3[text()='Good Luck To You, Leo Grande']
//       WebElement premier = driver.findElementByXPath("//h3[text()='Good Luck To You, Leo Grande']");
//       // ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", premier);
//        System.out.println("Name of the premier is: " + premier.getText());
////        //print the language of the same item Using Locator "XPath" //h3[text()='Good Luck To You, Leo Grande']/../div/following-sibling::div
////        WebElement language = driver.findElementByXPath("//h3[text()='Good Luck To You, Leo Grande']/../div/following-sibling::div");
////        System.out.println("language of the premier is: " + language.getText());
//    }
//    public  void testCase06() throws AWTException, InterruptedException {
//        System.out.println("Start Test case: testCase06");
//        //navigate to google homepage  https://www.linkedin.com/
//        driver.get("https://www.linkedin.com/");
//        //find textbox for email ID or phone Using Locator "ID" "session_key
//        //enter email ID  pllvbhas@gmail.com
//        WebElement email = driver.findElementById("session_key");
//        email.clear();
//        email.sendKeys("pllvbhas@gmail.com");
//        //find password textbox Using Locator "ID" "session_password" and enter password  "osssr05@#"
//        WebElement password = driver.findElementById("session_password");
//        password.clear();
//        password.sendKeys("osssr05@#");
//        //click on sign in button Using Locator "XPath" //button[@data-id='sign-in-form__submit-btn']
//        driver.findElementByXPath("//button[@data-id='sign-in-form__submit-btn']").click();
//        //find photos button and click on it
//        driver.findElementByXPath("//button[@aria-label='Add a photo']").click();
//        // creating object of Robot class
//        Robot rb = new Robot();
//        // copying File path to Clipboard
//        StringSelection str = new StringSelection("E:\\software-testing-principles.png");
//        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
//        //click on select image to share button Using Locator "ID" "image-sharing-detour-container__file-input"
////        driver.findElementById("image-sharing-detour-container__file-input").click();
//        Thread.sleep(3000); // suspending execution for specified time period
//
//        // press Contol+V for pasting
//        rb.keyPress(KeyEvent.VK_CONTROL);
//        rb.keyPress(KeyEvent.VK_V);
//
//        // release Contol+V for pasting
//        rb.keyRelease(KeyEvent.VK_CONTROL);
//        rb.keyRelease(KeyEvent.VK_V);
//
//        // for pressing and releasing Enter
//        rb.keyPress(KeyEvent.VK_ENTER);
//        rb.keyRelease(KeyEvent.VK_ENTER);
//        Thread.sleep(5000);
//        // Click on the "done" button Using Locator "XPath" //span[text()='Done']
//        WebElement doneButton = driver.findElement(By.xpath("//span[text()='Done']"));
//        doneButton.click();
//        //click on the "What do you want to talk about" field and send text "This image is uploaded through selenium script"
//        WebElement field = driver.findElement(By.xpath("//div[@class='ql-editor ql-blank']"));
//        field.sendKeys("This image is uploaded through selenium script using Robot class");
//
//        // Click on the "post" button Using Locator "XPath" //span[text()='Post']
//        WebElement postBttn = driver.findElement(By.xpath("//span[text()='Post']"));
//        postBttn.click();
//        // click on dismiss the post successfull notification popup using locator xpath  //button[contains(@class,'artdeco-toast')]
//        WebElement dismiss = driver.findElement(By.xpath("//button[contains(@class,'artdeco-toast')]"));
//        dismiss.click();
//    }
//    public  void imdb_ratings() throws InterruptedException {
//        boolean status;
//        System.out.println("Start Test case: imdb_ratings");
////        navigate to imdb site  https://www.imdb.com/chart/top
//        driver.get("https://www.imdb.com/chart/top");
////verify sort by button is displayed Using Locator "Class" Name lister-sort-by-label
//        status = driver.findElementByClassName("lister-sort-by-label").isDisplayed();
//        //click on dropdown Using Locator "Class" Name lister-sort-by"
//        WebElement sort_dropdown = driver.findElementByClassName("lister-sort-by");
//        sort_dropdown.click();
//        //Thread.sleep(3000);
//        //select imdb ratings Using Locator "XPath" //option[@value='ir:descending']
//        driver.findElementByXPath("//option[@value='ir:descending']").click();
//        //Thread.sleep(5000);
//        //find top rated movie
//        String top_rated_movie = driver.findElementsByXPath("//td[@class='titleColumn']").get(0).getText();
//        System.out.println("Top rated movie is: " + top_rated_movie);
//        //check the title of table Using Locator "XPath" //span[contains(text(),'Top 250 Movies')]
//        String TOP_listed = driver.findElementByXPath("//h1[contains(text(),'Top 250 Movies')]").getText();
//        System.out.println(TOP_listed);
//        //select release date Using Locator "XPath" //option[@value='us:descending']
//        sort_dropdown.click();
//        driver.findElementByXPath("//option[@value='us:descending']").click();
//        //select ascending order button Using Locator "XPath" //span[@title="Ascending order"]
//        WebElement order = driver.findElementByXPath("//span[starts-with(@class,'global-sprite lister-sort-reverse ')]");
//        order.click();
//
//        //get tiltle of oldest movie Using Locator "Link Text" The Kid
//        String oldest_movie = driver.findElementsByXPath("//td[@class='titleColumn']").get(0).getText();
//        System.out.println("Top rated movie is: " + oldest_movie);
//        //select descending order button.
//        order.click();
//        //select latest released movie and get 1st movie from the list Using Locator "Tag Name" a
//        String latest_movie = driver.findElementsByXPath("//td[@class='titleColumn']").get(0).getText();
//        System.out.println("Top rated movie is: " + latest_movie);
//        //click on dropdown Using Locator "Class" Name lister-sort-by"
//        sort_dropdown.click();
//        //select number of ratings Using Locator "XPath" //option[@value='nv:descending']
//        driver.findElementByXPath("//option[@value='nv:descending']").click();
//        //select the first movie from the list
//        String top_user_rated = driver.findElementsByXPath("//td[@class='titleColumn']").get(0).getText();
//        System.out.println("Top rated movie is: " + top_user_rated);
//    }
//    public  void w3school_Alert(){
//        System.out.println("Start Test case: testCase");
////        navigate to site w3school  W3Schools Tryit Editor - The prompt() Method
//        driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_prompt");
//
//        driver.switchTo().frame(driver.findElementByXPath("//*[@name='iframeResult']"));
////        WebDriverWait wait = new WebDriverWait(driver,30);
////        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Try it']")));
//        driver.findElementByXPath("//button[text()='Try it']").click();
//        //switch focus to alert
//        Alert a = driver.switchTo().alert();
//        //send alert text
//        driver.switchTo().alert().sendKeys("Pallavi Patil");
//        driver.switchTo().alert().accept();
//        //get alert text
//       // driver.switchTo().frame(driver.findElementByXPath("//*[@name='iframeResult']"));
//        boolean status = driver.findElementByXPath("//p[starts-with(text(),'Hello ')]").isDisplayed();
//        String s = driver.findElementByXPath("//p[starts-with(text(),'Hello ')]").getText();
//        System.out.println("Alert text is: " + s);
//
//
//
//
//    }
//    public  void herokuapp_frames(){
//        System.out.println("Start Test case: testCase");
////        navigate to google homepage  www.google.com
//        driver.get("https://the-internet.herokuapp.com/nested_frames");
//        //Locate the frame1 on the webPage
//        WebElement frame1=driver.findElementByXPath("//frame[@name='frame-top']");
//
//        //Switch to Frame1
//        driver.switchTo().frame(frame1);
//
////        //Number of Frames on a Frame1
//        int countIframesInFrame1 =driver. findElements(By. tagName("frame")). size();
//        System.out.println("Number of Frames inside the Frame1:"+countIframesInFrame1);
//        //Switch to child frame
//        driver.switchTo().frame(0);
//        String Frame1_child1_text = driver.findElementByTagName("body").getText();
//        System.out.println(Frame1_child1_text);
//        //Switch to Parent iFrame
//        driver.switchTo().parentFrame();
//        //Switch to child frame
//        driver.switchTo().frame(1);
//        String Frame1_child2_text = driver.findElementByTagName("body").getText();
//        System.out.println(Frame1_child2_text);
//        //Switch to Parent iFrame
//        driver.switchTo().parentFrame();
//        //Switch to child frame
//        driver.switchTo().frame(2);
//        String Frame1_child3_text = driver.findElementByTagName("body").getText();
//        System.out.println(Frame1_child3_text);
//        //driver.switchTo().parentFrame();
//        //Switch to default content
//        driver.switchTo().defaultContent();
//        //Locate the frame2 on the webPage
//        WebElement frame2=driver.findElementByXPath("//frame[@name='frame-bottom']");
//        //Switch to Frame2
//        driver.switchTo().frame(frame2);
//        String Frame2_text = driver.findElementByTagName("body").getText();
//        System.out.println(Frame2_text);
//
//    }
//    public  void w3school_Window(){
//        System.out.println("Start Test case: testCase");
////        navigate to site w3school  W3Schools Tryit Editor - The prompt() Method
//        driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_win_open");
//        driver.switchTo().frame(driver.findElementByXPath("//*[@name='iframeResult']"));
//        //click on tryit button Using Locator "XPath" //button[@onclick='myFunction()']
////        WebDriverWait wait = new WebDriverWait(driver,30);
////        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Try it']")));
//        driver.findElementByXPath("//button[text()='Try it']").click();
//        String parent=driver.getWindowHandle();
//
//        Set<String> s=driver.getWindowHandles();
//
//// Now iterate using Iterator
//        Iterator<String> I1= s.iterator();
//
//        while(I1.hasNext())
//        {
//
//            String child_window=I1.next();
//
//
//            if(!parent.equals(child_window))
//            {
//                driver.switchTo().window(child_window);
//                System.out.println(driver.switchTo().window(child_window).getCurrentUrl());
//                System.out.println(driver.switchTo().window(child_window).getTitle());
//                //Take the screenshot
//                File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//
//                //Copy the file to a location and use try catch block to handle exception
//                try {
//                    FileUtils.copyFile(screenshot, new File("C:\\projectScreenshots\\homePageScreenshot.png"));
//                } catch (IOException e) {
//                    System.out.println(e.getMessage());
//                }
//
//                driver.close();
//            }
//
//        }
////switch to the parent window
//        driver.switchTo().window(parent);
//
//    }


}
